import { View, TouchableOpacity, Text } from "react-native";

export function NextButton({ insets, onNext, isLastQuestion }) {
  return (
    <View
      style={{
        position: "absolute",
        bottom: 0,
        left: 0,
        right: 0,
        padding: 20,
        paddingBottom: insets.bottom + 20,
        backgroundColor: "#fff",
        borderTopWidth: 1,
        borderTopColor: "#E5E7EB",
      }}
    >
      <TouchableOpacity
        onPress={onNext}
        style={{
          backgroundColor: "#10B981",
          borderRadius: 16,
          paddingVertical: 16,
        }}
      >
        <Text
          style={{
            fontSize: 18,
            fontWeight: "600",
            color: "#fff",
            textAlign: "center",
          }}
        >
          {isLastQuestion ? "Finish Lesson" : "Next Question"}
        </Text>
      </TouchableOpacity>
    </View>
  );
}
