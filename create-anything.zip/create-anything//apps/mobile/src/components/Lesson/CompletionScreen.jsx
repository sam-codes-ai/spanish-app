import { View, Text, TouchableOpacity } from "react-native";
import { StatusBar } from "expo-status-bar";

export function CompletionScreen({
  insets,
  lessonTitle,
  score,
  totalQuestions,
  earnedXP,
  onContinue,
}) {
  const accuracy = Math.round((score / totalQuestions) * 100);

  return (
    <View style={{ flex: 1, backgroundColor: "#10B981" }}>
      <StatusBar style="light" />
      <View
        style={{
          flex: 1,
          paddingTop: insets.top + 40,
          paddingHorizontal: 20,
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <Text style={{ fontSize: 48, marginBottom: 16 }}>🎉</Text>
        <Text
          style={{
            fontSize: 32,
            fontWeight: "bold",
            color: "#fff",
            marginBottom: 8,
            textAlign: "center",
          }}
        >
          Lesson Complete!
        </Text>
        <Text
          style={{
            fontSize: 18,
            color: "#D1FAE5",
            marginBottom: 40,
            textAlign: "center",
          }}
        >
          Great job on completing {lessonTitle}
        </Text>

        <View
          style={{
            backgroundColor: "rgba(255,255,255,0.2)",
            borderRadius: 20,
            padding: 24,
            width: "100%",
            marginBottom: 32,
          }}
        >
          <View
            style={{ flexDirection: "row", justifyContent: "space-around" }}
          >
            <View style={{ alignItems: "center" }}>
              <Text style={{ fontSize: 36, fontWeight: "bold", color: "#fff" }}>
                {score}/{totalQuestions}
              </Text>
              <Text style={{ fontSize: 14, color: "#D1FAE5", marginTop: 4 }}>
                Correct
              </Text>
            </View>
            <View style={{ alignItems: "center" }}>
              <Text style={{ fontSize: 36, fontWeight: "bold", color: "#fff" }}>
                {accuracy}%
              </Text>
              <Text style={{ fontSize: 14, color: "#D1FAE5", marginTop: 4 }}>
                Accuracy
              </Text>
            </View>
            <View style={{ alignItems: "center" }}>
              <Text style={{ fontSize: 36, fontWeight: "bold", color: "#fff" }}>
                +{earnedXP}
              </Text>
              <Text style={{ fontSize: 14, color: "#D1FAE5", marginTop: 4 }}>
                XP Earned
              </Text>
            </View>
          </View>
        </View>

        <TouchableOpacity
          onPress={onContinue}
          style={{
            backgroundColor: "#fff",
            borderRadius: 16,
            paddingVertical: 16,
            paddingHorizontal: 32,
            width: "100%",
          }}
        >
          <Text
            style={{
              fontSize: 18,
              fontWeight: "600",
              color: "#10B981",
              textAlign: "center",
            }}
          >
            Continue Learning
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}
