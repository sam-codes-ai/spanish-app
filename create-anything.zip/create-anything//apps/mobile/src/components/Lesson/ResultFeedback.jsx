import { View, Text } from "react-native";

export function ResultFeedback({ question, isCorrect, userAnswer }) {
  return (
    <View
      style={{
        backgroundColor: isCorrect ? "#ECFDF5" : "#FEF2F2",
        borderRadius: 12,
        padding: 16,
        marginTop: 20,
      }}
    >
      <Text
        style={{
          fontSize: 16,
          fontWeight: "600",
          color: isCorrect ? "#065F46" : "#991B1B",
          marginBottom: 8,
        }}
      >
        {isCorrect ? "✓ Correct!" : "✗ Incorrect"}
      </Text>
      {question.type === "fill-in-blank" && !isCorrect && (
        <Text style={{ fontSize: 15, color: "#B91C1C", marginBottom: 8 }}>
          Correct answer: {question.answer}
        </Text>
      )}
      <Text
        style={{
          fontSize: 15,
          color: isCorrect ? "#047857" : "#B91C1C",
          lineHeight: 22,
        }}
      >
        {question.explanation}
      </Text>
    </View>
  );
}
