import { TouchableOpacity, Text } from "react-native";
import { Check, X } from "lucide-react-native";

export function MultipleChoice({
  question,
  selectedAnswer,
  showResult,
  onAnswer,
}) {
  return (
    <>
      {question.options.map((option, index) => {
        const isSelected = selectedAnswer === index;
        const isCorrect = index === question.correct;
        const showCorrect = showResult && isCorrect;
        const showIncorrect = showResult && isSelected && !isCorrect;

        return (
          <TouchableOpacity
            key={index}
            onPress={() => onAnswer(index)}
            disabled={showResult}
            style={{
              backgroundColor: showCorrect
                ? "#D1FAE5"
                : showIncorrect
                  ? "#FEE2E2"
                  : "#F9FAFB",
              borderWidth: 2,
              borderColor: showCorrect
                ? "#10B981"
                : showIncorrect
                  ? "#EF4444"
                  : isSelected
                    ? "#3B82F6"
                    : "#E5E7EB",
              borderRadius: 16,
              padding: 20,
              marginBottom: 12,
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "space-between",
            }}
          >
            <Text
              style={{
                fontSize: 17,
                color: showCorrect
                  ? "#065F46"
                  : showIncorrect
                    ? "#991B1B"
                    : "#111827",
                fontWeight: isSelected ? "600" : "400",
                flex: 1,
              }}
            >
              {option}
            </Text>
            {showCorrect && <Check color="#10B981" size={24} />}
            {showIncorrect && <X color="#EF4444" size={24} />}
          </TouchableOpacity>
        );
      })}
    </>
  );
}
