import { View, TextInput, TouchableOpacity, Text } from "react-native";

export function FillInBlank({
  question,
  textInput,
  showResult,
  onTextChange,
  onSubmit,
}) {
  const isCorrect =
    textInput.toLowerCase().trim() === question.answer.toLowerCase();

  return (
    <View>
      <TextInput
        value={textInput}
        onChangeText={onTextChange}
        placeholder="Type your answer..."
        style={{
          backgroundColor: "#F9FAFB",
          borderWidth: 2,
          borderColor: showResult
            ? isCorrect
              ? "#10B981"
              : "#EF4444"
            : "#E5E7EB",
          borderRadius: 16,
          padding: 20,
          fontSize: 17,
          marginBottom: 12,
        }}
        editable={!showResult}
        autoCapitalize="none"
        autoCorrect={false}
      />
      {!showResult && (
        <TouchableOpacity
          onPress={onSubmit}
          style={{
            backgroundColor: "#10B981",
            borderRadius: 16,
            paddingVertical: 16,
            marginTop: 8,
          }}
          disabled={!textInput.trim()}
        >
          <Text
            style={{
              fontSize: 18,
              fontWeight: "600",
              color: "#fff",
              textAlign: "center",
            }}
          >
            Check Answer
          </Text>
        </TouchableOpacity>
      )}
      {question.hint && !showResult && (
        <Text style={{ fontSize: 14, color: "#6B7280", marginTop: 12 }}>
          💡 Hint: {question.hint}
        </Text>
      )}
    </View>
  );
}
