import { View, Text, TouchableOpacity } from "react-native";
import { ArrowLeft } from "lucide-react-native";

export function LessonHeader({ insets, onBack, title, progress }) {
  return (
    <View
      style={{
        paddingTop: insets.top + 12,
        paddingHorizontal: 20,
        paddingBottom: 12,
        borderBottomWidth: 1,
        borderBottomColor: "#E5E7EB",
      }}
    >
      <View
        style={{
          flexDirection: "row",
          alignItems: "center",
          marginBottom: 12,
        }}
      >
        <TouchableOpacity onPress={onBack} style={{ marginRight: 16 }}>
          <ArrowLeft color="#111827" size={24} />
        </TouchableOpacity>
        <Text style={{ fontSize: 17, fontWeight: "600", color: "#111827" }}>
          {title}
        </Text>
      </View>

      {/* Progress Bar */}
      <View
        style={{
          height: 8,
          backgroundColor: "#E5E7EB",
          borderRadius: 4,
          overflow: "hidden",
        }}
      >
        <View
          style={{
            height: "100%",
            backgroundColor: "#10B981",
            width: `${progress}%`,
          }}
        />
      </View>
    </View>
  );
}
