import { View, Text, TouchableOpacity } from "react-native";
import { Image } from "expo-image";

export function Matching({
  question,
  matchedPairs,
  selectedSpanish,
  showResult,
  onMatch,
}) {
  return (
    <View>
      <View style={{ flexDirection: "row", gap: 12 }}>
        <View style={{ flex: 1 }}>
          <Text
            style={{
              fontSize: 14,
              fontWeight: "600",
              color: "#6B7280",
              marginBottom: 12,
            }}
          >
            SPANISH
          </Text>
          {question.pairs.map((pair, index) => {
            const isMatched = matchedPairs.some(
              (m) => m.spanish === pair.spanish,
            );
            const isSelected = selectedSpanish === pair.spanish;

            return (
              <TouchableOpacity
                key={index}
                onPress={() => !isMatched && onMatch(pair.spanish, null)}
                disabled={isMatched || showResult}
                style={{
                  backgroundColor: isMatched
                    ? "#D1FAE5"
                    : isSelected
                      ? "#DBEAFE"
                      : "#F9FAFB",
                  borderWidth: 2,
                  borderColor: isMatched
                    ? "#10B981"
                    : isSelected
                      ? "#3B82F6"
                      : "#E5E7EB",
                  borderRadius: 12,
                  padding: 12,
                  marginBottom: 8,
                  opacity: isMatched ? 0.5 : 1,
                }}
              >
                {pair.image && (
                  <Image
                    source={{ uri: pair.image }}
                    style={{
                      width: "100%",
                      height: 80,
                      borderRadius: 8,
                      marginBottom: 8,
                    }}
                    contentFit="cover"
                    transition={200}
                  />
                )}
                <Text
                  style={{
                    fontSize: 16,
                    fontWeight: isSelected ? "600" : "400",
                    color: "#111827",
                    textAlign: "center",
                  }}
                >
                  {pair.spanish}
                </Text>
              </TouchableOpacity>
            );
          })}
        </View>

        <View style={{ flex: 1 }}>
          <Text
            style={{
              fontSize: 14,
              fontWeight: "600",
              color: "#6B7280",
              marginBottom: 12,
            }}
          >
            ENGLISH
          </Text>
          {question.pairs.map((pair, index) => {
            const isMatched = matchedPairs.some(
              (m) => m.english === pair.english,
            );

            return (
              <TouchableOpacity
                key={index}
                onPress={() =>
                  !isMatched &&
                  selectedSpanish &&
                  onMatch(selectedSpanish, pair.english)
                }
                disabled={isMatched || !selectedSpanish || showResult}
                style={{
                  backgroundColor: isMatched ? "#D1FAE5" : "#F9FAFB",
                  borderWidth: 2,
                  borderColor: isMatched ? "#10B981" : "#E5E7EB",
                  borderRadius: 12,
                  padding: 16,
                  marginBottom: 8,
                  opacity: isMatched || !selectedSpanish ? 0.5 : 1,
                }}
              >
                <Text
                  style={{
                    fontSize: 16,
                    color: "#111827",
                    textAlign: "center",
                  }}
                >
                  {pair.english}
                </Text>
              </TouchableOpacity>
            );
          })}
        </View>
      </View>
      <Text
        style={{
          fontSize: 14,
          color: "#6B7280",
          marginTop: 12,
          textAlign: "center",
        }}
      >
        {selectedSpanish
          ? "Now tap the English match"
          : "Tap a Spanish word to start"}
      </Text>
    </View>
  );
}
