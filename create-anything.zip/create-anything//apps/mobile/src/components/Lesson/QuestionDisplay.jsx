import { View, Text } from "react-native";
import { Image } from "expo-image";
import { VideoView, useVideoPlayer } from "expo-video";

export function QuestionDisplay({ question, currentQuestion, totalQuestions }) {
  const player = useVideoPlayer(question.video || "", (player) => {
    if (question.video) {
      player.loop = true;
      player.muted = false;
    }
  });

  return (
    <View>
      <Text
        style={{
          fontSize: 14,
          color: "#6B7280",
          fontWeight: "600",
          marginBottom: 8,
        }}
      >
        QUESTION {currentQuestion + 1} OF {totalQuestions}
      </Text>

      {/* Image Display */}
      {question.image && (
        <View
          style={{ marginBottom: 24, borderRadius: 16, overflow: "hidden" }}
        >
          <Image
            source={{ uri: question.image }}
            style={{ width: "100%", height: 200 }}
            contentFit="cover"
            transition={300}
          />
        </View>
      )}

      {/* Video Display */}
      {question.video && (
        <View
          style={{
            marginBottom: 24,
            borderRadius: 16,
            overflow: "hidden",
            backgroundColor: "#000",
          }}
        >
          <VideoView
            style={{ width: "100%", height: 200 }}
            player={player}
            allowsFullscreen
            allowsPictureInPicture
          />
        </View>
      )}

      <Text
        style={{
          fontSize: 24,
          fontWeight: "bold",
          color: "#111827",
          marginBottom: 32,
          lineHeight: 32,
        }}
      >
        {question.question}
      </Text>
    </View>
  );
}
