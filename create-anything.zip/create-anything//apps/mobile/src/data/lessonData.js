export const lessonData = {
  greetings: {
    title: "Greetings & Basics",
    questions: [
      {
        type: "multiple-choice",
        question: 'How do you say "Hello" in Spanish?',
        options: ["Hola", "Adiós", "Gracias", "Por favor"],
        correct: 0,
        explanation: '"Hola" is the most common way to say hello in Spanish.',
        image:
          "https://images.unsplash.com/photo-1582213782179-e0d53f98f2ca?w=800&q=80",
      },
      {
        type: "multiple-choice",
        question: 'What does "¿Cómo estás?" mean?',
        options: [
          "What is your name?",
          "How are you?",
          "Where are you from?",
          "Nice to meet you",
        ],
        correct: 1,
        explanation:
          '"¿Cómo estás?" is used to ask someone how they are doing.',
        image:
          "https://images.unsplash.com/photo-1521791136064-7986c2920216?w=800&q=80",
      },
      {
        type: "fill-in-blank",
        question: 'Complete: "_____ días" (Good morning)',
        answer: "buenos",
        hint: 'Starts with "b"',
        explanation: '"Buenos días" means good morning in Spanish.',
        image:
          "https://images.unsplash.com/photo-1470252649378-9c29740c9fa8?w=800&q=80",
      },
      {
        type: "multiple-choice",
        question: 'How do you say "Thank you"?',
        options: ["Por favor", "De nada", "Gracias", "Lo siento"],
        correct: 2,
        explanation: '"Gracias" means thank you in Spanish.',
        image:
          "https://images.unsplash.com/photo-1532629345422-7515f3d16bb6?w=800&q=80",
      },
      {
        type: "matching",
        question: "Match the Spanish greeting with its English meaning:",
        pairs: [
          { spanish: "Hola", english: "Hello" },
          { spanish: "Adiós", english: "Goodbye" },
          { spanish: "Gracias", english: "Thank you" },
          { spanish: "Por favor", english: "Please" },
        ],
        explanation:
          "These are the most essential Spanish greetings and polite expressions.",
      },
      {
        type: "multiple-choice",
        question: 'What is "Goodbye" in Spanish?',
        options: ["Hola", "Adiós", "Hasta mañana", "Nos vemos"],
        correct: 1,
        explanation: '"Adiós" is the most common way to say goodbye.',
        image:
          "https://images.unsplash.com/photo-1515041219749-89347f83291a?w=800&q=80",
      },
      {
        type: "fill-in-blank",
        question: 'Fill in: "Mucho _____" (Nice to meet you)',
        answer: "gusto",
        hint: 'Rhymes with "justo"',
        explanation:
          '"Mucho gusto" is how you say "Nice to meet you" in Spanish.',
        image:
          "https://images.unsplash.com/photo-1556484687-30636164638b?w=800&q=80",
      },
      {
        type: "multiple-choice",
        question: 'How do you say "See you later"?',
        options: ["Hasta luego", "Buenos días", "Buenas noches", "Adiós"],
        correct: 0,
        explanation:
          '"Hasta luego" literally means "until later" and is used to say "see you later".',
      },
    ],
  },
  numbers: {
    title: "Numbers 1-100",
    questions: [
      {
        type: "multiple-choice",
        question: 'What is "10" in Spanish?',
        options: ["Nueve", "Diez", "Once", "Doce"],
        correct: 1,
        explanation: '"Diez" is the Spanish word for ten.',
        image:
          "https://images.unsplash.com/photo-1611329532992-0b7d094e1e44?w=800&q=80",
      },
      {
        type: "fill-in-blank",
        question: 'Write the number: "cinco" in digits',
        answer: "5",
        hint: "It's less than ten",
        explanation: '"Cinco" means five in Spanish.',
        image:
          "https://images.unsplash.com/photo-1634128221889-82ed6efebfc3?w=800&q=80",
      },
      {
        type: "multiple-choice",
        question: 'How do you say "25"?',
        options: ["Veinticinco", "Treinta y cinco", "Quince", "Veinte"],
        correct: 0,
        explanation: '"Veinticinco" means twenty-five in Spanish.',
        image:
          "https://images.unsplash.com/photo-1616628188467-0a5c8dcd5a2e?w=800&q=80",
      },
      {
        type: "matching",
        question: "Match the Spanish numbers with their English equivalents:",
        pairs: [
          { spanish: "uno", english: "1" },
          { spanish: "tres", english: "3" },
          { spanish: "siete", english: "7" },
          { spanish: "diez", english: "10" },
        ],
        explanation:
          "Learning numbers is essential for daily conversations in Spanish.",
      },
      {
        type: "multiple-choice",
        question: 'What is "50" in Spanish?',
        options: ["Cuarenta", "Cincuenta", "Sesenta", "Setenta"],
        correct: 1,
        explanation: '"Cincuenta" is fifty in Spanish.',
      },
      {
        type: "fill-in-blank",
        question: 'Complete: "_____ y uno" (Twenty-one)',
        answer: "veinte",
        hint: "The number 20",
        explanation: '"Veinte y uno" or "veintiuno" means twenty-one.',
      },
    ],
  },
  food: {
    title: "Food & Dining",
    questions: [
      {
        type: "multiple-choice",
        question: 'What is "water" in Spanish?',
        options: ["Leche", "Agua", "Jugo", "Café"],
        correct: 1,
        explanation: '"Agua" means water in Spanish.',
        image:
          "https://images.unsplash.com/photo-1548839140-29a749e1cf4d?w=800&q=80",
      },
      {
        type: "fill-in-blank",
        question: 'Fill in: "Una _____ de café" (A cup of coffee)',
        answer: "taza",
        hint: "The Spanish word for cup",
        explanation: '"Una taza de café" means a cup of coffee.',
        image:
          "https://images.unsplash.com/photo-1509042239860-f550ce710b93?w=800&q=80",
      },
      {
        type: "multiple-choice",
        question: 'How do you say "I would like..."?',
        options: ["Yo quiero", "Quisiera", "Necesito", "Tengo"],
        correct: 1,
        explanation: '"Quisiera" is a polite way to say "I would like".',
        image:
          "https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=800&q=80",
      },
      {
        type: "matching",
        question: "Match the Spanish food words with English:",
        pairs: [
          {
            spanish: "Pan",
            english: "Bread",
            image:
              "https://images.unsplash.com/photo-1509440159596-0249088772ff?w=400&q=80",
          },
          {
            spanish: "Agua",
            english: "Water",
            image:
              "https://images.unsplash.com/photo-1548839140-29a749e1cf4d?w=400&q=80",
          },
          {
            spanish: "Carne",
            english: "Meat",
            image:
              "https://images.unsplash.com/photo-1588347818036-e0bed19eab84?w=400&q=80",
          },
          {
            spanish: "Fruta",
            english: "Fruit",
            image:
              "https://images.unsplash.com/photo-1610832958506-aa56368176cf?w=400&q=80",
          },
        ],
        explanation: "These are basic food vocabulary words used daily.",
      },
      {
        type: "multiple-choice",
        question: 'What does "la cuenta" mean?',
        options: ["The menu", "The bill", "The food", "The drink"],
        correct: 1,
        explanation:
          '"La cuenta" means "the bill" - what you ask for when you want to pay.',
        image:
          "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=800&q=80",
      },
      {
        type: "fill-in-blank",
        question: 'Complete: "_____ hambre" (I\'m hungry)',
        answer: "tengo",
        hint: 'The verb "to have"',
        explanation:
          '"Tengo hambre" literally means "I have hunger" but translates to "I\'m hungry".',
      },
    ],
  },
  conversation: {
    title: "Daily Conversations",
    questions: [
      {
        type: "multiple-choice",
        question: 'How do you ask "What is your name?"',
        options: [
          "¿Cómo estás?",
          "¿Cómo te llamas?",
          "¿De dónde eres?",
          "¿Cuántos años tienes?",
        ],
        correct: 1,
        explanation:
          '"¿Cómo te llamas?" literally means "How do you call yourself?" and is used to ask someone\'s name.',
        image:
          "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=800&q=80",
      },
      {
        type: "fill-in-blank",
        question: 'Fill in: "Me _____ Juan" (My name is Juan)',
        answer: "llamo",
        hint: 'The verb "to call"',
        explanation:
          '"Me llamo" means "I call myself" and is how you introduce yourself.',
      },
      {
        type: "matching",
        question: "Match the questions with their meanings:",
        pairs: [
          { spanish: "¿Cómo estás?", english: "How are you?" },
          { spanish: "¿De dónde eres?", english: "Where are you from?" },
          { spanish: "¿Qué haces?", english: "What do you do?" },
          { spanish: "¿Hablas inglés?", english: "Do you speak English?" },
        ],
        explanation: "These are common conversation starters in Spanish.",
      },
      {
        type: "multiple-choice",
        question: 'What does "¿Dónde está el baño?" mean?',
        options: [
          "Where is the bathroom?",
          "Where is the restaurant?",
          "Where are you?",
          "Where is the hotel?",
        ],
        correct: 0,
        explanation: "This is one of the most useful phrases when traveling!",
        image:
          "https://images.unsplash.com/photo-1584622650111-993a426fbf0a?w=800&q=80",
      },
      {
        type: "fill-in-blank",
        question: 'Complete: "No _____ español" (I don\'t speak Spanish)',
        answer: "hablo",
        hint: 'The verb "to speak"',
        explanation: '"No hablo español" means "I don\'t speak Spanish".',
      },
    ],
  },
  pronunciation: {
    title: "Pronunciation Practice",
    questions: [
      {
        type: "multiple-choice",
        question: 'Which letter combination sounds like "ny" in English?',
        options: ["ll", "ñ", "ch", "rr"],
        correct: 1,
        explanation:
          'The letter "ñ" sounds like "ny" in "canyon". Example: "mañana" (tomorrow).',
        video:
          "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
      },
      {
        type: "fill-in-blank",
        question: 'The Spanish "j" sounds like the "h" in which English word?',
        answer: "hello",
        hint: "A greeting",
        explanation:
          'The Spanish "j" (as in "jefe") sounds like a strong "h" sound.',
        video:
          "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4",
      },
      {
        type: "matching",
        question: "Match the Spanish sound with the English equivalent:",
        pairs: [
          { spanish: "ñ", english: "ny in canyon" },
          { spanish: "ll", english: "y in yes" },
          { spanish: "rr", english: "rolled r" },
          { spanish: "j", english: "h in hello" },
        ],
        explanation:
          "Understanding these sounds is key to proper Spanish pronunciation.",
      },
      {
        type: "multiple-choice",
        question: "In Spanish, vowels are pronounced:",
        options: [
          "Like in English",
          "The same way every time",
          "Silently sometimes",
          "With different accents",
        ],
        correct: 1,
        explanation:
          "Spanish vowels are always pronounced the same way, making pronunciation more predictable!",
      },
      {
        type: "multiple-choice",
        question: 'How many syllables does "trabajar" have?',
        options: ["2", "3", "4", "5"],
        correct: 1,
        explanation: '"Trabajar" (to work) has 3 syllables: tra-ba-jar.',
      },
    ],
  },
  grammar: {
    title: "Grammar Essentials",
    questions: [
      {
        type: "multiple-choice",
        question:
          'What is the conjugation of "hablar" (to speak) for "yo" (I)?',
        options: ["hablo", "hablas", "habla", "hablan"],
        correct: 0,
        explanation:
          '"Yo hablo" means "I speak". Regular -ar verbs drop the -ar and add -o for "yo".',
      },
      {
        type: "fill-in-blank",
        question: 'Fill in: "Tú _____ español" (You speak Spanish)',
        answer: "hablas",
        hint: 'Conjugate "hablar" for "tú"',
        explanation:
          '"Tú hablas" means "you speak". For "tú", add -as to the stem.',
      },
      {
        type: "matching",
        question: "Match the pronouns with their English equivalents:",
        pairs: [
          { spanish: "yo", english: "I" },
          { spanish: "tú", english: "you (informal)" },
          { spanish: "él/ella", english: "he/she" },
          { spanish: "nosotros", english: "we" },
        ],
        explanation:
          "Spanish pronouns are often optional because the verb conjugation shows who is acting.",
      },
      {
        type: "multiple-choice",
        question: 'What is the plural of "el libro" (the book)?',
        options: ["los libro", "el libros", "los libros", "las libros"],
        correct: 2,
        explanation:
          '"Los libros" means "the books". Masculine plural uses "los" and adds -s to the noun.',
        image:
          "https://images.unsplash.com/photo-1507842217343-583bb7270b66?w=800&q=80",
      },
      {
        type: "fill-in-blank",
        question: 'Complete: "_____ casa" (the house - feminine)',
        answer: "la",
        hint: "Feminine article",
        explanation: '"La casa" uses "la" because "casa" is a feminine noun.',
      },
      {
        type: "multiple-choice",
        question: "Which sentence is correct?",
        options: [
          "Yo es estudiante",
          "Yo soy estudiante",
          "Yo está estudiante",
          "Yo eres estudiante",
        ],
        correct: 1,
        explanation:
          '"Yo soy estudiante" means "I am a student". "Soy" is the correct conjugation of "ser" for "yo".',
      },
    ],
  },
};
