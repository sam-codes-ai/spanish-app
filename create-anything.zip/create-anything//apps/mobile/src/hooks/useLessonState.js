import { useState } from "react";
import { saveLessonProgress } from "@/utils/lessonProgress";

export function useLessonState(lesson, lessonId) {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState(null);
  const [showResult, setShowResult] = useState(false);
  const [score, setScore] = useState(0);
  const [completed, setCompleted] = useState(false);
  const [textInput, setTextInput] = useState("");
  const [matchedPairs, setMatchedPairs] = useState([]);
  const [selectedSpanish, setSelectedSpanish] = useState(null);
  const [earnedXP, setEarnedXP] = useState(0);

  const question = lesson.questions[currentQuestion];

  const handleAnswer = (index) => {
    if (showResult) return;

    setSelectedAnswer(index);
    setShowResult(true);

    if (index === question.correct) {
      setScore(score + 1);
    }
  };

  const handleFillInBlank = () => {
    if (showResult) return;

    const isCorrect =
      textInput.toLowerCase().trim() === question.answer.toLowerCase();
    setShowResult(true);

    if (isCorrect) {
      setScore(score + 1);
    }
  };

  const handleMatching = (spanishText, englishText) => {
    if (showResult) return;

    if (selectedSpanish === null) {
      setSelectedSpanish(spanishText);
    } else {
      const correctPair = question.pairs.find(
        (p) => p.spanish === selectedSpanish && p.english === englishText,
      );

      if (correctPair) {
        setMatchedPairs([...matchedPairs, correctPair]);
      }

      setSelectedSpanish(null);

      if (matchedPairs.length + 1 === question.pairs.length) {
        const allCorrect = question.pairs.every(
          (pair) =>
            matchedPairs.some(
              (m) => m.spanish === pair.spanish && m.english === pair.english,
            ) ||
            (pair.spanish === selectedSpanish && pair.english === englishText),
        );
        setShowResult(true);
        if (allCorrect) {
          setScore(score + 1);
        }
      }
    }
  };

  const handleNext = async () => {
    if (currentQuestion < lesson.questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedAnswer(null);
      setShowResult(false);
      setTextInput("");
      setMatchedPairs([]);
      setSelectedSpanish(null);
    } else {
      // Lesson completed
      try {
        const result = await saveLessonProgress(
          lessonId,
          score,
          lesson.questions.length,
        );
        setEarnedXP(result.earnedXP);
        setCompleted(true);
      } catch (error) {
        console.error("Error saving progress:", error);
      }
    }
  };

  const resetQuestion = () => {
    setSelectedAnswer(null);
    setShowResult(false);
    setTextInput("");
    setMatchedPairs([]);
    setSelectedSpanish(null);
  };

  return {
    currentQuestion,
    selectedAnswer,
    showResult,
    score,
    completed,
    textInput,
    matchedPairs,
    selectedSpanish,
    earnedXP,
    question,
    handleAnswer,
    handleFillInBlank,
    handleMatching,
    handleNext,
    setTextInput,
    resetQuestion,
  };
}
