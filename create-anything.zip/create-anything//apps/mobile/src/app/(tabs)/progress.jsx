import { View, Text, ScrollView, TouchableOpacity } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { StatusBar } from "expo-status-bar";
import {
  Trophy,
  Flame,
  Star,
  Target,
  Award,
  Zap,
  Settings,
} from "lucide-react-native";
import { useState, useEffect } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";

export default function ProgressScreen() {
  const insets = useSafeAreaInsets();
  const [stats, setStats] = useState({
    streak: 0,
    totalXP: 0,
    lessonsCompleted: 0,
    accuracy: 0,
    dailyXP: 0,
    dailyGoal: 50,
  });
  const [showGoalSettings, setShowGoalSettings] = useState(false);

  useEffect(() => {
    loadStats();
  }, []);

  const loadStats = async () => {
    try {
      const streak = await AsyncStorage.getItem("streak");
      const totalXP = await AsyncStorage.getItem("totalXP");
      const completed = await AsyncStorage.getItem("completedLessons");
      const accuracy = await AsyncStorage.getItem("accuracy");
      const dailyXP = await AsyncStorage.getItem("dailyXP");
      const dailyGoal = await AsyncStorage.getItem("dailyGoal");
      const lastDate = await AsyncStorage.getItem("lastLessonDate");
      const today = new Date().toDateString();

      setStats({
        streak: streak ? parseInt(streak) : 0,
        totalXP: totalXP ? parseInt(totalXP) : 0,
        lessonsCompleted: completed ? JSON.parse(completed).length : 0,
        accuracy: accuracy ? parseInt(accuracy) : 0,
        dailyXP: lastDate === today && dailyXP ? parseInt(dailyXP) : 0,
        dailyGoal: dailyGoal ? parseInt(dailyGoal) : 50,
      });
    } catch (error) {
      console.error("Error loading stats:", error);
    }
  };

  const setDailyGoal = async (goal) => {
    try {
      await AsyncStorage.setItem("dailyGoal", goal.toString());
      setStats({ ...stats, dailyGoal: goal });
      setShowGoalSettings(false);
    } catch (error) {
      console.error("Error setting daily goal:", error);
    }
  };

  const achievements = [
    {
      id: 1,
      title: "First Steps",
      description: "Complete your first lesson",
      icon: Star,
      unlocked: stats.lessonsCompleted >= 1,
      color: "#F59E0B",
    },
    {
      id: 2,
      title: "Week Warrior",
      description: "Maintain a 7-day streak",
      icon: Flame,
      unlocked: stats.streak >= 7,
      color: "#EF4444",
    },
    {
      id: 3,
      title: "XP Master",
      description: "Earn 500 XP",
      icon: Zap,
      unlocked: stats.totalXP >= 500,
      color: "#8B5CF6",
    },
    {
      id: 4,
      title: "Perfect Score",
      description: "Get 100% on any lesson",
      icon: Target,
      unlocked: stats.accuracy === 100,
      color: "#10B981",
    },
    {
      id: 5,
      title: "Dedicated Learner",
      description: "Complete 10 lessons",
      icon: Award,
      unlocked: stats.lessonsCompleted >= 10,
      color: "#3B82F6",
    },
    {
      id: 6,
      title: "Month Master",
      description: "Maintain a 30-day streak",
      icon: Trophy,
      unlocked: stats.streak >= 30,
      color: "#EC4899",
    },
  ];

  const goalOptions = [25, 50, 75, 100, 150, 200];

  return (
    <View style={{ flex: 1, backgroundColor: "#F9FAFB" }}>
      <StatusBar style="dark" />

      <View
        style={{
          paddingTop: insets.top + 20,
          paddingHorizontal: 20,
          paddingBottom: 16,
          backgroundColor: "#fff",
          borderBottomWidth: 1,
          borderBottomColor: "#E5E7EB",
        }}
      >
        <Text style={{ fontSize: 28, fontWeight: "bold", color: "#111827" }}>
          Your Progress
        </Text>
        <Text style={{ fontSize: 15, color: "#6B7280", marginTop: 4 }}>
          Track your learning journey
        </Text>
      </View>

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{
          padding: 20,
          paddingBottom: insets.bottom + 20,
        }}
        showsVerticalScrollIndicator={false}
      >
        {/* Daily Goal Card */}
        <View
          style={{
            backgroundColor: "#fff",
            borderRadius: 16,
            padding: 20,
            marginBottom: 24,
            shadowColor: "#000",
            shadowOffset: { width: 0, height: 2 },
            shadowOpacity: 0.05,
            shadowRadius: 8,
            elevation: 2,
          }}
        >
          <View
            style={{
              flexDirection: "row",
              justifyContent: "space-between",
              alignItems: "center",
              marginBottom: 16,
            }}
          >
            <View>
              <Text
                style={{
                  fontSize: 20,
                  fontWeight: "bold",
                  color: "#111827",
                  marginBottom: 4,
                }}
              >
                Today's Goal
              </Text>
              <Text style={{ fontSize: 14, color: "#6B7280" }}>
                {stats.dailyXP}/{stats.dailyGoal} XP
              </Text>
            </View>
            <TouchableOpacity
              onPress={() => setShowGoalSettings(!showGoalSettings)}
              style={{
                width: 40,
                height: 40,
                borderRadius: 10,
                backgroundColor: "#F3F4F6",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <Settings color="#6B7280" size={20} />
            </TouchableOpacity>
          </View>

          <View
            style={{
              height: 12,
              backgroundColor: "#E5E7EB",
              borderRadius: 6,
              overflow: "hidden",
              marginBottom: 12,
            }}
          >
            <View
              style={{
                height: "100%",
                backgroundColor: "#10B981",
                width: `${Math.min((stats.dailyXP / stats.dailyGoal) * 100, 100)}%`,
              }}
            />
          </View>

          {stats.dailyXP >= stats.dailyGoal ? (
            <Text
              style={{
                fontSize: 14,
                color: "#10B981",
                fontWeight: "600",
                textAlign: "center",
              }}
            >
              🎉 Goal completed! Amazing work!
            </Text>
          ) : (
            <Text
              style={{ fontSize: 14, color: "#6B7280", textAlign: "center" }}
            >
              {stats.dailyGoal - stats.dailyXP} XP to go
            </Text>
          )}

          {showGoalSettings && (
            <View
              style={{
                marginTop: 20,
                paddingTop: 20,
                borderTopWidth: 1,
                borderTopColor: "#E5E7EB",
              }}
            >
              <Text
                style={{
                  fontSize: 14,
                  fontWeight: "600",
                  color: "#6B7280",
                  marginBottom: 12,
                }}
              >
                SET DAILY GOAL
              </Text>
              <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
                {goalOptions.map((goal) => (
                  <TouchableOpacity
                    key={goal}
                    onPress={() => setDailyGoal(goal)}
                    style={{
                      paddingVertical: 12,
                      paddingHorizontal: 20,
                      borderRadius: 12,
                      backgroundColor:
                        stats.dailyGoal === goal ? "#10B981" : "#F3F4F6",
                    }}
                  >
                    <Text
                      style={{
                        fontSize: 16,
                        fontWeight: "600",
                        color: stats.dailyGoal === goal ? "#fff" : "#111827",
                      }}
                    >
                      {goal} XP
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>
          )}
        </View>

        {/* Stats Grid */}
        <View
          style={{
            flexDirection: "row",
            flexWrap: "wrap",
            gap: 12,
            marginBottom: 24,
          }}
        >
          <View
            style={{
              flex: 1,
              minWidth: "47%",
              backgroundColor: "#fff",
              borderRadius: 16,
              padding: 16,
              shadowColor: "#000",
              shadowOffset: { width: 0, height: 2 },
              shadowOpacity: 0.05,
              shadowRadius: 8,
              elevation: 2,
            }}
          >
            <View
              style={{
                width: 40,
                height: 40,
                borderRadius: 10,
                backgroundColor: "#FEF3C7",
                alignItems: "center",
                justifyContent: "center",
                marginBottom: 12,
              }}
            >
              <Flame color="#F59E0B" size={24} />
            </View>
            <Text
              style={{
                fontSize: 28,
                fontWeight: "bold",
                color: "#111827",
                marginBottom: 4,
              }}
            >
              {stats.streak}
            </Text>
            <Text style={{ fontSize: 14, color: "#6B7280" }}>Day Streak</Text>
          </View>

          <View
            style={{
              flex: 1,
              minWidth: "47%",
              backgroundColor: "#fff",
              borderRadius: 16,
              padding: 16,
              shadowColor: "#000",
              shadowOffset: { width: 0, height: 2 },
              shadowOpacity: 0.05,
              shadowRadius: 8,
              elevation: 2,
            }}
          >
            <View
              style={{
                width: 40,
                height: 40,
                borderRadius: 10,
                backgroundColor: "#DBEAFE",
                alignItems: "center",
                justifyContent: "center",
                marginBottom: 12,
              }}
            >
              <Star color="#3B82F6" size={24} />
            </View>
            <Text
              style={{
                fontSize: 28,
                fontWeight: "bold",
                color: "#111827",
                marginBottom: 4,
              }}
            >
              {stats.totalXP}
            </Text>
            <Text style={{ fontSize: 14, color: "#6B7280" }}>Total XP</Text>
          </View>

          <View
            style={{
              flex: 1,
              minWidth: "47%",
              backgroundColor: "#fff",
              borderRadius: 16,
              padding: 16,
              shadowColor: "#000",
              shadowOffset: { width: 0, height: 2 },
              shadowOpacity: 0.05,
              shadowRadius: 8,
              elevation: 2,
            }}
          >
            <View
              style={{
                width: 40,
                height: 40,
                borderRadius: 10,
                backgroundColor: "#D1FAE5",
                alignItems: "center",
                justifyContent: "center",
                marginBottom: 12,
              }}
            >
              <Trophy color="#10B981" size={24} />
            </View>
            <Text
              style={{
                fontSize: 28,
                fontWeight: "bold",
                color: "#111827",
                marginBottom: 4,
              }}
            >
              {stats.lessonsCompleted}
            </Text>
            <Text style={{ fontSize: 14, color: "#6B7280" }}>Lessons Done</Text>
          </View>

          <View
            style={{
              flex: 1,
              minWidth: "47%",
              backgroundColor: "#fff",
              borderRadius: 16,
              padding: 16,
              shadowColor: "#000",
              shadowOffset: { width: 0, height: 2 },
              shadowOpacity: 0.05,
              shadowRadius: 8,
              elevation: 2,
            }}
          >
            <View
              style={{
                width: 40,
                height: 40,
                borderRadius: 10,
                backgroundColor: "#F3E8FF",
                alignItems: "center",
                justifyContent: "center",
                marginBottom: 12,
              }}
            >
              <Target color="#8B5CF6" size={24} />
            </View>
            <Text
              style={{
                fontSize: 28,
                fontWeight: "bold",
                color: "#111827",
                marginBottom: 4,
              }}
            >
              {stats.accuracy}%
            </Text>
            <Text style={{ fontSize: 14, color: "#6B7280" }}>Accuracy</Text>
          </View>
        </View>

        {/* Achievements */}
        <Text
          style={{
            fontSize: 20,
            fontWeight: "bold",
            color: "#111827",
            marginBottom: 16,
          }}
        >
          Achievements
        </Text>

        {achievements.map((achievement) => {
          const Icon = achievement.icon;
          return (
            <View
              key={achievement.id}
              style={{
                backgroundColor: "#fff",
                borderRadius: 16,
                padding: 16,
                marginBottom: 12,
                flexDirection: "row",
                alignItems: "center",
                shadowColor: "#000",
                shadowOffset: { width: 0, height: 2 },
                shadowOpacity: 0.05,
                shadowRadius: 8,
                elevation: 2,
                opacity: achievement.unlocked ? 1 : 0.5,
              }}
            >
              <View
                style={{
                  width: 56,
                  height: 56,
                  borderRadius: 12,
                  backgroundColor: achievement.unlocked
                    ? achievement.color + "15"
                    : "#F3F4F6",
                  alignItems: "center",
                  justifyContent: "center",
                  marginRight: 16,
                }}
              >
                <Icon
                  color={achievement.unlocked ? achievement.color : "#9CA3AF"}
                  size={28}
                />
              </View>

              <View style={{ flex: 1 }}>
                <Text
                  style={{
                    fontSize: 17,
                    fontWeight: "600",
                    color: "#111827",
                    marginBottom: 2,
                  }}
                >
                  {achievement.title}
                </Text>
                <Text style={{ fontSize: 14, color: "#6B7280" }}>
                  {achievement.description}
                </Text>
                {achievement.unlocked && (
                  <Text
                    style={{
                      fontSize: 13,
                      color: achievement.color,
                      marginTop: 4,
                      fontWeight: "600",
                    }}
                  >
                    ✓ Unlocked
                  </Text>
                )}
              </View>
            </View>
          );
        })}
      </ScrollView>
    </View>
  );
}
