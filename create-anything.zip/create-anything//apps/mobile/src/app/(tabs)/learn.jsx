import { View, Text, ScrollView, TouchableOpacity } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { StatusBar } from "expo-status-bar";
import { BookOpen, CheckCircle2, Lock } from "lucide-react-native";
import { useState, useEffect } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";

export default function LearnScreen() {
  const insets = useSafeAreaInsets();
  const [completedLessons, setCompletedLessons] = useState([]);

  useEffect(() => {
    loadCompletedLessons();
  }, []);

  const loadCompletedLessons = async () => {
    try {
      const completed = await AsyncStorage.getItem("completedLessons");
      if (completed) {
        setCompletedLessons(JSON.parse(completed));
      }
    } catch (error) {
      console.error("Error loading completed lessons:", error);
    }
  };

  const learningPath = [
    { id: "greetings", title: "Greetings & Basics", level: 1, unlocked: true },
    { id: "numbers", title: "Numbers 1-100", level: 2, unlocked: true },
    { id: "food", title: "Food & Dining", level: 3, unlocked: true },
    {
      id: "conversation",
      title: "Daily Conversations",
      level: 4,
      unlocked: true,
    },
    { id: "pronunciation", title: "Pronunciation", level: 5, unlocked: true },
    { id: "grammar", title: "Grammar Essentials", level: 6, unlocked: true },
  ];

  return (
    <View style={{ flex: 1, backgroundColor: "#F9FAFB" }}>
      <StatusBar style="dark" />

      <View
        style={{
          paddingTop: insets.top + 20,
          paddingHorizontal: 20,
          paddingBottom: 16,
          backgroundColor: "#fff",
          borderBottomWidth: 1,
          borderBottomColor: "#E5E7EB",
        }}
      >
        <Text style={{ fontSize: 28, fontWeight: "bold", color: "#111827" }}>
          Learning Path
        </Text>
        <Text style={{ fontSize: 15, color: "#6B7280", marginTop: 4 }}>
          Follow the path to fluency
        </Text>
      </View>

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{
          padding: 20,
          paddingBottom: insets.bottom + 20,
        }}
        showsVerticalScrollIndicator={false}
      >
        {learningPath.map((item, index) => {
          const isCompleted = completedLessons.includes(item.id);
          const isLocked = !item.unlocked;

          return (
            <View key={item.id} style={{ marginBottom: 24 }}>
              {/* Connector Line */}
              {index > 0 && (
                <View
                  style={{
                    width: 3,
                    height: 24,
                    backgroundColor: isCompleted ? "#10B981" : "#E5E7EB",
                    marginLeft: 27,
                    marginBottom: 8,
                  }}
                />
              )}

              <TouchableOpacity
                disabled={isLocked}
                style={{
                  backgroundColor: "#fff",
                  borderRadius: 16,
                  padding: 16,
                  flexDirection: "row",
                  alignItems: "center",
                  shadowColor: "#000",
                  shadowOffset: { width: 0, height: 2 },
                  shadowOpacity: 0.05,
                  shadowRadius: 8,
                  elevation: 2,
                  opacity: isLocked ? 0.5 : 1,
                }}
              >
                {/* Level Circle */}
                <View
                  style={{
                    width: 56,
                    height: 56,
                    borderRadius: 28,
                    backgroundColor: isCompleted
                      ? "#10B981"
                      : isLocked
                        ? "#E5E7EB"
                        : "#3B82F6",
                    alignItems: "center",
                    justifyContent: "center",
                    marginRight: 16,
                  }}
                >
                  {isCompleted ? (
                    <CheckCircle2 color="#fff" size={28} />
                  ) : isLocked ? (
                    <Lock color="#9CA3AF" size={24} />
                  ) : (
                    <BookOpen color="#fff" size={28} />
                  )}
                </View>

                <View style={{ flex: 1 }}>
                  <Text
                    style={{
                      fontSize: 12,
                      color: "#6B7280",
                      fontWeight: "600",
                      marginBottom: 2,
                    }}
                  >
                    LEVEL {item.level}
                  </Text>
                  <Text
                    style={{
                      fontSize: 17,
                      fontWeight: "600",
                      color: "#111827",
                    }}
                  >
                    {item.title}
                  </Text>
                  {isCompleted && (
                    <Text
                      style={{
                        fontSize: 14,
                        color: "#10B981",
                        marginTop: 4,
                        fontWeight: "500",
                      }}
                    >
                      ✓ Completed
                    </Text>
                  )}
                  {isLocked && (
                    <Text
                      style={{ fontSize: 14, color: "#9CA3AF", marginTop: 4 }}
                    >
                      Complete previous lessons to unlock
                    </Text>
                  )}
                </View>
              </TouchableOpacity>
            </View>
          );
        })}

        <View
          style={{
            backgroundColor: "#EFF6FF",
            borderRadius: 12,
            padding: 16,
            marginTop: 8,
          }}
        >
          <Text
            style={{
              fontSize: 16,
              fontWeight: "600",
              color: "#1E40AF",
              marginBottom: 4,
            }}
          >
            💡 Learning Tip
          </Text>
          <Text style={{ fontSize: 14, color: "#3B82F6", lineHeight: 20 }}>
            Practice a little every day for the best results. Consistency is
            more important than long study sessions!
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}
