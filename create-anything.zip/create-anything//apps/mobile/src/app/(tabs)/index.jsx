import { View, Text, ScrollView, TouchableOpacity } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { StatusBar } from "expo-status-bar";
import { useRouter } from "expo-router";
import {
  Flame,
  Star,
  BookOpen,
  MessageCircle,
  Volume2,
  Pencil,
} from "lucide-react-native";
import { useState, useEffect } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";

export default function HomeScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const [streak, setStreak] = useState(0);
  const [totalXP, setTotalXP] = useState(0);
  const [dailyXP, setDailyXP] = useState(0);
  const [dailyGoal, setDailyGoal] = useState(50);

  useEffect(() => {
    loadProgress();
  }, []);

  const loadProgress = async () => {
    try {
      const savedStreak = await AsyncStorage.getItem("streak");
      const savedXP = await AsyncStorage.getItem("totalXP");
      const savedDailyXP = await AsyncStorage.getItem("dailyXP");
      const savedDailyGoal = await AsyncStorage.getItem("dailyGoal");
      const lastDate = await AsyncStorage.getItem("lastLessonDate");
      const today = new Date().toDateString();

      if (savedStreak) setStreak(parseInt(savedStreak));
      if (savedXP) setTotalXP(parseInt(savedXP));
      if (savedDailyGoal) setDailyGoal(parseInt(savedDailyGoal));

      // Reset daily XP if it's a new day
      if (lastDate !== today) {
        setDailyXP(0);
        await AsyncStorage.setItem("dailyXP", "0");
      } else if (savedDailyXP) {
        setDailyXP(parseInt(savedDailyXP));
      }
    } catch (error) {
      console.error("Error loading progress:", error);
    }
  };

  const lessons = [
    {
      id: "greetings",
      title: "Greetings & Basics",
      description: "Learn essential Spanish greetings",
      icon: MessageCircle,
      color: "#10B981",
      difficulty: "Beginner",
      xp: 50,
    },
    {
      id: "numbers",
      title: "Numbers 1-100",
      description: "Master Spanish numbers",
      icon: Star,
      color: "#3B82F6",
      difficulty: "Beginner",
      xp: 50,
    },
    {
      id: "food",
      title: "Food & Dining",
      description: "Order food like a local",
      icon: BookOpen,
      color: "#F59E0B",
      difficulty: "Beginner",
      xp: 75,
    },
    {
      id: "conversation",
      title: "Daily Conversations",
      description: "Practice real-world dialogues",
      icon: MessageCircle,
      color: "#8B5CF6",
      difficulty: "Intermediate",
      xp: 100,
    },
    {
      id: "pronunciation",
      title: "Pronunciation Practice",
      description: "Perfect your Spanish accent",
      icon: Volume2,
      color: "#EC4899",
      difficulty: "All Levels",
      xp: 60,
    },
    {
      id: "grammar",
      title: "Grammar Essentials",
      description: "Understand verb conjugations",
      icon: Pencil,
      color: "#06B6D4",
      difficulty: "Intermediate",
      xp: 100,
    },
  ];

  return (
    <View style={{ flex: 1, backgroundColor: "#F9FAFB" }}>
      <StatusBar style="dark" />

      {/* Header */}
      <View
        style={{
          backgroundColor: "#10B981",
          paddingTop: insets.top + 20,
          paddingBottom: 24,
          paddingHorizontal: 20,
        }}
      >
        <Text
          style={{
            fontSize: 28,
            fontWeight: "bold",
            color: "#fff",
            marginBottom: 4,
          }}
        >
          ¡Hola! 👋
        </Text>
        <Text style={{ fontSize: 16, color: "#D1FAE5" }}>
          Ready to learn Spanish today?
        </Text>

        {/* Daily Goal Progress */}
        <View
          style={{
            backgroundColor: "rgba(255,255,255,0.2)",
            borderRadius: 12,
            padding: 16,
            marginTop: 20,
          }}
        >
          <View
            style={{
              flexDirection: "row",
              justifyContent: "space-between",
              marginBottom: 8,
            }}
          >
            <Text style={{ fontSize: 14, color: "#fff", fontWeight: "600" }}>
              Daily Goal
            </Text>
            <Text style={{ fontSize: 14, color: "#D1FAE5", fontWeight: "600" }}>
              {dailyXP}/{dailyGoal} XP
            </Text>
          </View>
          <View
            style={{
              height: 8,
              backgroundColor: "rgba(255,255,255,0.3)",
              borderRadius: 4,
              overflow: "hidden",
            }}
          >
            <View
              style={{
                height: "100%",
                backgroundColor: "#fff",
                width: `${Math.min((dailyXP / dailyGoal) * 100, 100)}%`,
              }}
            />
          </View>
          {dailyXP >= dailyGoal && (
            <Text
              style={{
                fontSize: 13,
                color: "#fff",
                marginTop: 8,
                fontWeight: "600",
              }}
            >
              🎉 Goal completed! Keep it up!
            </Text>
          )}
        </View>

        {/* Stats */}
        <View style={{ flexDirection: "row", marginTop: 12, gap: 12 }}>
          <View
            style={{
              flex: 1,
              backgroundColor: "rgba(255,255,255,0.2)",
              borderRadius: 12,
              padding: 12,
              flexDirection: "row",
              alignItems: "center",
              gap: 8,
            }}
          >
            <Flame color="#FFF" size={20} />
            <View>
              <Text style={{ fontSize: 20, fontWeight: "bold", color: "#fff" }}>
                {streak}
              </Text>
              <Text style={{ fontSize: 12, color: "#D1FAE5" }}>Day Streak</Text>
            </View>
          </View>

          <View
            style={{
              flex: 1,
              backgroundColor: "rgba(255,255,255,0.2)",
              borderRadius: 12,
              padding: 12,
              flexDirection: "row",
              alignItems: "center",
              gap: 8,
            }}
          >
            <Star color="#FFF" size={20} />
            <View>
              <Text style={{ fontSize: 20, fontWeight: "bold", color: "#fff" }}>
                {totalXP}
              </Text>
              <Text style={{ fontSize: 12, color: "#D1FAE5" }}>Total XP</Text>
            </View>
          </View>
        </View>
      </View>

      {/* Lessons */}
      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{
          padding: 20,
          paddingBottom: insets.bottom + 20,
        }}
        showsVerticalScrollIndicator={false}
      >
        <Text
          style={{
            fontSize: 20,
            fontWeight: "bold",
            color: "#111827",
            marginBottom: 16,
          }}
        >
          Choose Your Lesson
        </Text>

        {lessons.map((lesson) => {
          const Icon = lesson.icon;
          return (
            <TouchableOpacity
              key={lesson.id}
              onPress={() => router.push(`/lesson/${lesson.id}`)}
              style={{
                backgroundColor: "#fff",
                borderRadius: 16,
                padding: 16,
                marginBottom: 12,
                flexDirection: "row",
                alignItems: "center",
                shadowColor: "#000",
                shadowOffset: { width: 0, height: 2 },
                shadowOpacity: 0.05,
                shadowRadius: 8,
                elevation: 2,
              }}
            >
              <View
                style={{
                  width: 56,
                  height: 56,
                  borderRadius: 12,
                  backgroundColor: lesson.color + "15",
                  alignItems: "center",
                  justifyContent: "center",
                  marginRight: 16,
                }}
              >
                <Icon color={lesson.color} size={28} />
              </View>

              <View style={{ flex: 1 }}>
                <Text
                  style={{
                    fontSize: 17,
                    fontWeight: "600",
                    color: "#111827",
                    marginBottom: 2,
                  }}
                >
                  {lesson.title}
                </Text>
                <Text
                  style={{ fontSize: 14, color: "#6B7280", marginBottom: 6 }}
                >
                  {lesson.description}
                </Text>
                <View
                  style={{
                    flexDirection: "row",
                    alignItems: "center",
                    gap: 12,
                  }}
                >
                  <View
                    style={{
                      backgroundColor: "#F3F4F6",
                      paddingHorizontal: 8,
                      paddingVertical: 4,
                      borderRadius: 6,
                    }}
                  >
                    <Text
                      style={{
                        fontSize: 12,
                        color: "#6B7280",
                        fontWeight: "500",
                      }}
                    >
                      {lesson.difficulty}
                    </Text>
                  </View>
                  <Text
                    style={{
                      fontSize: 12,
                      color: "#10B981",
                      fontWeight: "600",
                    }}
                  >
                    +{lesson.xp} XP
                  </Text>
                </View>
              </View>
            </TouchableOpacity>
          );
        })}
      </ScrollView>
    </View>
  );
}
