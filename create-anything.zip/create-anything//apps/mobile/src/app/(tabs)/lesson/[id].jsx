import { View, ScrollView } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { StatusBar } from "expo-status-bar";
import { useLocalSearchParams, useRouter } from "expo-router";
import { lessonData } from "@/data/lessonData";
import { useLessonState } from "@/hooks/useLessonState";
import { LessonHeader } from "@/components/Lesson/LessonHeader";
import { CompletionScreen } from "@/components/Lesson/CompletionScreen";
import { QuestionDisplay } from "@/components/Lesson/QuestionDisplay";
import { MultipleChoice } from "@/components/Lesson/MultipleChoice";
import { FillInBlank } from "@/components/Lesson/FillInBlank";
import { Matching } from "@/components/Lesson/Matching";
import { ResultFeedback } from "@/components/Lesson/ResultFeedback";
import { NextButton } from "@/components/Lesson/NextButton";

export default function LessonScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { id } = useLocalSearchParams();

  const lesson = lessonData[id] || lessonData.greetings;

  const {
    currentQuestion,
    selectedAnswer,
    showResult,
    score,
    completed,
    textInput,
    matchedPairs,
    selectedSpanish,
    earnedXP,
    question,
    handleAnswer,
    handleFillInBlank,
    handleMatching,
    handleNext,
    setTextInput,
  } = useLessonState(lesson, id);

  const progress = ((currentQuestion + 1) / lesson.questions.length) * 100;

  if (completed) {
    return (
      <CompletionScreen
        insets={insets}
        lessonTitle={lesson.title}
        score={score}
        totalQuestions={lesson.questions.length}
        earnedXP={earnedXP}
        onContinue={() => router.back()}
      />
    );
  }

  const isCorrect =
    (question.type === "multiple-choice" &&
      selectedAnswer === question.correct) ||
    (question.type === "fill-in-blank" &&
      textInput.toLowerCase().trim() === question.answer.toLowerCase()) ||
    (question.type === "matching" &&
      matchedPairs.length === question.pairs.length);

  return (
    <View style={{ flex: 1, backgroundColor: "#fff" }}>
      <StatusBar style="dark" />

      <LessonHeader
        insets={insets}
        onBack={() => router.back()}
        title={lesson.title}
        progress={progress}
      />

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{
          padding: 20,
          paddingBottom: insets.bottom + 100,
        }}
        showsVerticalScrollIndicator={false}
      >
        <QuestionDisplay
          question={question}
          currentQuestion={currentQuestion}
          totalQuestions={lesson.questions.length}
        />

        {/* Multiple Choice */}
        {question.type === "multiple-choice" && (
          <MultipleChoice
            question={question}
            selectedAnswer={selectedAnswer}
            showResult={showResult}
            onAnswer={handleAnswer}
          />
        )}

        {/* Fill in the Blank */}
        {question.type === "fill-in-blank" && (
          <FillInBlank
            question={question}
            textInput={textInput}
            showResult={showResult}
            onTextChange={setTextInput}
            onSubmit={handleFillInBlank}
          />
        )}

        {/* Matching */}
        {question.type === "matching" && (
          <Matching
            question={question}
            matchedPairs={matchedPairs}
            selectedSpanish={selectedSpanish}
            showResult={showResult}
            onMatch={handleMatching}
          />
        )}

        {showResult && (
          <ResultFeedback
            question={question}
            isCorrect={isCorrect}
            userAnswer={textInput}
          />
        )}
      </ScrollView>

      {/* Bottom Button */}
      {showResult && (
        <NextButton
          insets={insets}
          onNext={handleNext}
          isLastQuestion={currentQuestion >= lesson.questions.length - 1}
        />
      )}
    </View>
  );
}
