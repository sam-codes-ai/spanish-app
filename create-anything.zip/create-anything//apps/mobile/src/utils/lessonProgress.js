import AsyncStorage from "@react-native-async-storage/async-storage";

export async function saveLessonProgress(lessonId, score, totalQuestions) {
  const earnedXP = Math.round((score / totalQuestions) * 100);
  const accuracy = Math.round((score / totalQuestions) * 100);

  try {
    // Update total XP
    const currentXP = await AsyncStorage.getItem("totalXP");
    const newXP = (currentXP ? parseInt(currentXP) : 0) + earnedXP;
    await AsyncStorage.setItem("totalXP", newXP.toString());

    // Update daily XP
    const today = new Date().toDateString();
    const lastDate = await AsyncStorage.getItem("lastLessonDate");
    const dailyXP = await AsyncStorage.getItem("dailyXP");

    if (lastDate === today) {
      const newDailyXP = (dailyXP ? parseInt(dailyXP) : 0) + earnedXP;
      await AsyncStorage.setItem("dailyXP", newDailyXP.toString());
    } else {
      await AsyncStorage.setItem("dailyXP", earnedXP.toString());
      await AsyncStorage.setItem("lastLessonDate", today);
    }

    // Update completed lessons
    const completedLessons = await AsyncStorage.getItem("completedLessons");
    const completed = completedLessons ? JSON.parse(completedLessons) : [];
    if (!completed.includes(lessonId)) {
      completed.push(lessonId);
      await AsyncStorage.setItem("completedLessons", JSON.stringify(completed));
    }

    // Update streak (simplified - just increment)
    const currentStreak = await AsyncStorage.getItem("streak");
    const newStreak = (currentStreak ? parseInt(currentStreak) : 0) + 1;
    await AsyncStorage.setItem("streak", newStreak.toString());

    // Update accuracy
    await AsyncStorage.setItem("accuracy", accuracy.toString());

    return { earnedXP, accuracy };
  } catch (error) {
    console.error("Error saving progress:", error);
    throw error;
  }
}
